# telegram-bot-api-sample

> See also: http://code-samples.space/notes/60de07185eed1167a96fea28

_TODO: Грузить списки с Гугл Диска_

## Quick start

### `yarn && yarn start`

### `.prod.env` sample

```bash
TG_BOT_TOKEN=<YOUR_TOKEN>

# OPTIONAL:
DEVELOPER_NAME=<DEVELOPER_NAME>
DEVELOPER_CHAT_ID=<DEVELOPER_CHAT_ID>
```
